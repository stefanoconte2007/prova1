import javax.swing.*;
public class ProgRobot
{
 public static void main(String[] args) 
    {
        //Dichiarazione degli oggetti
        Robot r1;
        Robot r2;
        String seriale,marca,prezzo;
        int p;
        //Input  e creazione del primo oggetto
        seriale=JOptionPane.showInputDialog(null,"Inserisci il seriale del Robot ");
        marca=JOptionPane.showInputDialog(null,"Inserisci la marca del Robot ");
        prezzo=JOptionPane.showInputDialog(null,"Inserisci il prezzo del Robot ");
        p=Integer.parseInt(prezzo);
        r1=new Robot(seriale,marca,p);
        //Input e creazione del secondo oggetto
         seriale=JOptionPane.showInputDialog(null,"Inserisci il secondo valore del  seriale del Robot ");
        marca=JOptionPane.showInputDialog(null,"Inserisci il secondo valore della marca del Robot ");
        prezzo=JOptionPane.showInputDialog(null,"Inserisci il secondo valore del  Prezzo del Robot ");
        p=Integer.parseInt(prezzo);
        r2=new Robot(seriale,marca,p);
        //Andiamo a richiamare il metodo visualizza con i valori dei due oggetti
        r1.visualizza();
        r2.visualizza();
        //richiamiamo il metodo statico massimo
        Robot.massimo(r1,r2);
        
        
        
        
        
        
    }

}
