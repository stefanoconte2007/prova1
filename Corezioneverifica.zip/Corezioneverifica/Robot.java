import javax.swing.*;
public class Robot
{
    //Dichiarazione degli attributi
   private String seriale;
   private String marca;
   private int prezzo;
   //primo Costruttore con tre attributi
   public Robot(String seriale,String marca,int prezzo)
   {
       this.seriale=seriale;
       this.marca=marca;
       this.prezzo=prezzo;
   }
   //socondo costruttore con solo due attributi
   public Robot(String marca,int prezzo)
   {
       this.seriale="";
       this.marca=marca;
       this.prezzo=prezzo;
   }
   // Definizione del Information hiding,con i metodi get e set del seriale
   public String getseriale()
   {
       return seriale;
   }
   public void setseriale(String seriale)
   {
       this.seriale=seriale;
   }
   //Definizione del Information hiding,con i metodi get e set della marca
    public String getmarca()
   {
       return marca;
   }
   public void setmarca(String marca)
   {
       this.marca=marca;
   }
    //Definizione del Information hiding,con i metodi get e set del prezzo
    public int getprezzo()
   {
       return prezzo;
   }
   public void setprezzo(int prezzo)
   {
     this.prezzo=prezzo;  
   }
   //Definizione del metodo visualizza
   public void visualizza()
   {
       JOptionPane.showMessageDialog(null,"Il seriale e' "+seriale+"\n la marca e' "+marca+"\n il prezzo e' "+prezzo);
   }
   //Definizione del metodo massimo
   public static void massimo(Robot a1,Robot a2)
   {
       if(a1.getprezzo()>a2.getprezzo())
       {
           JOptionPane.showMessageDialog(null,"Il robot che ha il prezzo  maggiore  ha come seriale: "+a1.getseriale()+"\n marca: "+a1.getmarca()+"\n prezzo: "+a1.getprezzo());
       }
       else
       {
        JOptionPane.showMessageDialog(null,"Il robot che ha il prezzo  maggiore  ha come seriale: "+a2.getseriale()+"\n marca: "+a2.getmarca()+"\n prezzo: "+a2.getprezzo());           
       }
       
   }
   //Metodo che conta
   public static void conta(Robot a1,Robot a2)
   {
       String seriale1=a1.getseriale();
       String seriale2=a2.getseriale();
       
       seriale1=seriale1.toLowerCase();
       seriale2=seriale2.toLowerCase();
       
       int lunghezzaS1=0,lunghezzaS2=0;
       char carattere;
       for(int i=0;i<seriale1.length();i++)
       {
           carattere=seriale1.charAt(i);
           if(carattere=='a'||carattere=='e'||carattere=='i'||carattere=='o'||carattere=='u')
           {
               lunghezzaS1++;
           }
           
       }
       for(int i=0;i<seriale2.length();i++)
       {
           carattere=seriale1.charAt(i);
           if(carattere=='a'||carattere=='e'||carattere=='i'||carattere=='o'||carattere=='u')
           {
               lunghezzaS2++;
           }
           
       }
       if(lunghezzaS1>lunghezzaS2)
       {
           JOptionPane.showMessageDialog(null,"Il robot che ha piu' vocali "+a1.getseriale()+"Numero di vocali"+lunghezzaS1);
       }
       else
       {
           JOptionPane.showMessageDialog(null,"Il robot che ha piu' vocali "+a2.getseriale()+"Numero di vocali"+lunghezzaS2);
       }
   }
    
}
