import javax.swing.*;
//Difinire la classe SuperRobot che viene ereditato dalla classe Robot

public class SuperRobot extends Robot
{
  public String optional;
  public SuperRobot(String seriale,String marca,int prezzo,String optional)
  {
     super(seriale,marca,prezzo);
     this.optional=optional;
  }
}
